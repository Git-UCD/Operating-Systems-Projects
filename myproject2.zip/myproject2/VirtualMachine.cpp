#include "VirtualMachine.h"
#include "Machine.h"
#include <iostream>
#include <queue>
using namespace std;

volatile int TIMER;

class TCB{
	//state
	TVMStatus pstate;
	//context

	//priprity
	//file
	//MM
	
};

extern "C" {


TVMMainEntry VMLoadModule(const char *module);
TVMStatus VMFilePrint(int filedescriptor, const char *format, ...);

void  callbackAlarm( void* t){
	
	TIMER -= 10;
    
}

TVMStatus VMStart(int tickms, int argc, char *argv[]){
	MachineInitialize();
	// request time
	// int time = 0;
	int flag;
	TIMER = 0;
	TVMMainEntry mainEntry =  VMLoadModule(argv[0]);
	TMachineAlarmCallback callback = callbackAlarm;
	MachineRequestAlarm(tickms*1000,callback,&flag);
	mainEntry(argc,argv);

	cout << "flag: " << flag << endl;
	TVMThreadEntry vmstart = 
	VMThreadCreate(vmstart,)



	
	
	



	return VM_STATUS_SUCCESS; 
}

TVMStatus VMThreadSleep(TVMTick tick){
	while(TIMER != 0){

	}

return VM_STATUS_SUCCESS; 	
}

TVMStatus VMThreadCreate(TVMThreadEntry entry, void *param, TVMMemorySize memsize, TVMThreadPriority prio, TVMThreadIDRef tid){
	TCB threadB;
return VM_STATUS_SUCCESS; 
}


// TVMStatus VMTickMS(int *tickmsref){

// }

// TVMStatus VMTickCount(TVMTickRef tickref){

// }

TVMStatus VMFileWrite(int filedescriptor, void *data, int *length){
	write(filedescriptor,data,*length);
//	TMachineFileCallback mycall = 
//	MachineFileWrite(filedescriptor, *data, *length, mycallback, void *calldata);
	return VM_STATUS_SUCCESS;
}

}
